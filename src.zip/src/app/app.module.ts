import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';

import { ChartsModule } from 'ng2-charts/ng2-charts';

import { MyApp } from './app.component';

import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { AccountPage } from '../pages/account/account';
import { HousingServicePage } from '../pages/housing-service/housing-service';
import { DashboardPage } from '../pages/dashboard/dashboard';
import { BillingPage } from '../pages/billing/billing';
import { SettingsPage } from '../pages/settings/settings';
import { NotificationsPage } from '../pages/notifications/notifications';
import { ChangePwPage } from '../pages/change-pw/change-pw'
import { AboutPage } from '../pages/about/about';
 
import { AuthService } from '../providers/auth-service';

@NgModule({
  declarations: [
    MyApp,
    LoginPage,
    HomePage,
    AccountPage,
    HousingServicePage,
    DashboardPage,
    BillingPage,
    SettingsPage,
    NotificationsPage,
    ChangePwPage,
    AboutPage
  ],
  imports: [
    IonicModule.forRoot(MyApp),
    ChartsModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,
    HomePage,
    AccountPage,
    HousingServicePage,
    DashboardPage,
    BillingPage,
    SettingsPage,
    NotificationsPage,
    ChangePwPage,
    AboutPage
  ],
  providers: [{provide: ErrorHandler, useClass: IonicErrorHandler}, AuthService]
})
export class AppModule {}
